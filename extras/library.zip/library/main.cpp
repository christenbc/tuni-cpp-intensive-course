/*
####################################################################
# TIE-02207 Programming 2: Basics, S2019                           #
#                                                                  #
# Project2: Library                                                #
# Program description: Implements library to insert and retrieve   #
# books details.			  									   #
#                                                                  #
# File: main.cpp                                                   #
# Description: Starts executing the program.                       #
#                                                                  #
# Author: Amir Salah, 281781, amir.salah@tuni.fi                   #
####################################################################
*/

#include <map>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <algorithm>

const int ON_THE_SHELF = -1;
const int MAX_RESERVATIONS = 100;

using namespace std;

struct Book {
    string title;
    string author;
    int reservations;
};

using Library_Map = map< string, map<string, vector<Book>>>;



// Split function from a previous exercise
vector<string> split(const string& s, const char delimiter,
bool ignore_empty = false){
    vector<string> result;
    string tmp = s;

    while(tmp.find(delimiter) != string::npos){
        string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());

        if(not (ignore_empty and new_part.empty())) result.push_back(new_part);
    }
    if ( not (ignore_empty and tmp.empty())) result.push_back(tmp);
    return result;
}



/// Insert a book into the existing libraries datastructure
/// param:
///     Library_Map libraries: The libraries data structure to store library information
///     string library_name
///     string author
///     string title
///     int reservations
/// no return
void add_book(Library_Map& libraries, const string library_name, const string author, const string title, const int reservations){

    // if library does not exist, add it
    if (libraries.find(library_name) == libraries.end())    libraries.insert( {library_name, {}} );

    // if author does not exist add it
    if (libraries.at(library_name).find(author) == libraries.at(library_name).end() ) libraries.at(library_name).insert( {author, {} } );

    // add book titles
    vector<Book>& books = libraries.at(library_name).at(author);

    // update reservation, if more than one exist
    for (Book& existing_book : books)
        if (existing_book.title == title){
            existing_book.reservations = reservations;
            return;
        }

    // if no book is found, we add it
    books.push_back( {title, author, reservations} );
}



/// Read the input file
/// param:
///     Library_Map libraries: The libraries data structure to store library information
/// returns: A boolean indicating whether the file was read properly
bool read_input(Library_Map& libraries){

    string file_name = "";
    cout << "Input file: ";
    getline(cin, file_name);

    // read variable, file is just a name
    ifstream file(file_name);
    if(not file){
        cout << "Error: the input file cannot be opened" << endl;
        return false;
    }

    string line = "";

    // return true as long as there is something to read
    while (getline(file, line)) {
        vector <string> fields = split(line, ';', true);

        if(fields.size() != 4){
            cout << "Error: empty field" << endl;
            return false;
        }

        string library_name = fields.at(0);
        string author = fields.at(1);
        string title = fields.at(2);

        int reservations = 0;
        if (fields.at(3) == "on-the-shelf")     reservations = ON_THE_SHELF;            // if book.reseravations == ON_THE_SHELF
        else    reservations = stoi(fields.at(3));

        add_book(libraries, library_name, author, title, reservations);
    }

    file.close();
    return true;

}



/// Display the book that are available for reservations
/// param:
///     Library_Map libraries: The libraries data structure to store library information
///     string book_name
/// no returns
void c_reservable(Library_Map& libraries, string book_name){

    // book name can also be given with quotation marks  so you need to remove them if the exist
    // if after removal the size is 0 then it's empty. Output an error in command and return
    if (book_name.at(0) == '"' and book_name.at(book_name.size()-1)  == '"'){
        book_name = book_name.substr(1, book_name.size()-2);
        if (book_name.size() == 0){
            cout << "Error: error in command reservable" << endl;
            return;
        }
    }

    int min_reservations = MAX_RESERVATIONS;
    bool was_found = false;
    set<string> places;

    for (auto& library: libraries)
        for (auto& author: library.second)
            for (Book& book: author.second)
                if (book.title == book_name) {
                    was_found = true;
                    if (book.reservations == min_reservations) places.insert(library.first);
                    else if (book.reservations < min_reservations) {
                        places.clear();
                        min_reservations = book.reservations;
                        places.insert(library.first);
                    }
                }

    if (not was_found) cout << "Book is not a library book." << endl;
    else if (min_reservations == MAX_RESERVATIONS) cout << "The book is not reservable from any library." << endl;
    else {
        // not included in the documentation but it's in the auto tests
        if (min_reservations == ON_THE_SHELF) cout << "on the shelf" << endl;
        else cout << min_reservations << " reservations" << endl;
        for (string place : places) {
            cout << "--- " << place << endl;
        }
    }
}



/// displays all book of a given library
/// param:
///     Library_Map libraries: The libraries data structure to store library information
///     string library_name
/// no returns
void c_material(Library_Map& libraries, string library_name){
    if (libraries.find(library_name) != libraries.end()) {
        for (auto& author: libraries[library_name])
            for (Book& book: author.second)
                    cout << book.author << ": " << book.title << endl;
    }
    else 	cout<<"Error: unknown library name"<<endl;
}



/// displays all book of a given library and a given author
/// param:
///     Library_Map libraries: The libraries data structure to store library information
///     string library_name
///     string author_name
/// no returns
void c_books(Library_Map& libraries, string library_name, string author_name){
    if (libraries.find(library_name) != libraries.end()) {
        if (libraries.at(library_name).find(author_name) != libraries.at(library_name).end() )
            for (Book& book: libraries[library_name][author_name])
                if (book.reservations == -1 )
                    cout << book.title << " --- " << "on the shelf" << endl;
                else
                    cout << book.title << " --- " << book.reservations << " reservations" << endl;
        else
            cout<<"Error: unknown author"<<endl;
    }
    else
        cout<<"Error: unknown library name"<<endl;
}



/// displays all book that can be found from the shelf
/// param:
///     Library_Map libraries: The libraries data structure to store library information
/// no returns
void c_loanable(Library_Map& libraries){
    vector <string> to_loan;
    for (auto& library: libraries)
        for (auto& author: library.second)
            for (Book& book: author.second)
                if (book.reservations == -1 )
                    to_loan.push_back(book.author + ": " + book.title);
    sort(to_loan.begin(), to_loan.end());
    for (auto& loan: to_loan)
        cout << loan << endl;
}



/// Read the commands and send the approprite portion of the string input to other funcitons
/// param:
///     Library_Map libraries: The libraries data structure to store library information
///     string command: the input string
/// returns: A boolean whether to exist the loop or keep executing
bool interpret_command(Library_Map& libraries, string command){

    vector<string> split_command = split(command, ' ', true);

    // example: command =  reservable "Programming Languages"
    //          command_name = reservable
    string command_name = split_command.at(0);

    if (command.empty()) return true;

    else if (command_name == "quit") return false;

    else if (command_name == "reservable") {

        // if the input command has no parameters
        if (command.size() == command_name.size()){
            cout << "Error: error in command " << command_name << endl;
            return true;
        }

        string book_name = command.substr(command_name.size()+1, command.size());
        c_reservable(libraries, book_name);
    }

    else if (command_name == "books") {

        if (split_command.size() != 3){
            cout << "Error: error in command " << command_name << endl;
            return true;
        }

        string library_name = split_command.at(1);
        string author_name = split_command.at(2);
        c_books(libraries, library_name, author_name);
    }

    else if (command_name == "material") {
        string library_name = split_command.at(1);
        c_material(libraries, library_name);
    }

    else if (command_name == "libraries")
        for (auto& library: libraries)
            cout << library.first << endl;

    else if (command_name == "loanable")    c_loanable(libraries);

    else    cout << "Error: Unknown command: " << command_name << endl;

    return true;
}



int main()
{
    // data structure is the following map< string, map<string, vector<Book>>>
    // The structure is introduced a name into the class scope above to avoid repitions
    Library_Map libraries;
    if (not read_input(libraries))
        return EXIT_FAILURE;

    // Iterate through the input commands
    while (true) {
        string command = "";
        cout << "> ";
        getline(cin, command);

        if( not interpret_command(libraries, command) ) 	break;
    }

}
